package com.rnandini.myfirstapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.rnandini.myfirstapp.rider.RiderHomeActivity;

public class SplashActivity extends AppCompatActivity {

    SharedPreferences MainActivity;
    SharedPreferences user_session;
    String currentUserType;
    boolean isLoggedIn;

    private static int SPLASH_SCREEN=4000;
    Animation topanim,bottomAnim;
    TextView logo,slogan;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        topanim= AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim=AnimationUtils.loadAnimation(this,R.anim.bottom_animation);
        image=findViewById(R.id.splashIcon);
        logo=findViewById(R.id.splashTitle);
        slogan=findViewById(R.id.splashslogan);
        image.setAnimation(topanim);
        logo.setAnimation(bottomAnim);
        slogan.setAnimation(bottomAnim);

        //User session
        user_session = this.getSharedPreferences("user_details", MODE_PRIVATE);
        //Get the Session Values
        currentUserType = user_session.getString("cu_type", "");
        isLoggedIn = user_session.getBoolean("isLoggedIn", false);



        new Handler().postDelayed(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void run() {

        MainActivity = getSharedPreferences("onBordingScreen",MODE_PRIVATE);
        boolean isFirstTime = MainActivity.getBoolean("firstTime",true);



        if (isFirstTime){

          SharedPreferences.Editor editor = MainActivity.edit();
          editor.putBoolean("firstTime",false);
          editor.commit();

          Intent intent = new Intent(getApplicationContext(), MainActivity.class);
          startActivity(intent);
          finish();


           }
        else {
            //Check whether user available or not

            if(isLoggedIn){

                if (currentUserType.equals("Rider")) {
                    startActivity(new Intent(SplashActivity.this, RiderHomeActivity.class));

                } else {
                    startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                }
            }else{
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
                }
            }
        },2000);
    }
}