package com.rnandini.myfirstapp;

public class DonationList {

    private String donationType;
    private String donationWeight;
    private String mobile;
    private String donationVehivle;
    private String donationdate;
    private String donationtime;
    private String latitude;
    private String longitude;
    private String street;
    private String status;
    private String address;
    private String userID;
    private String fName;
    private int state;
    private String key;
    private String riderid;
    private String riderdate;
    private String ridertime;
    private String riderkey;






    public String getDonationType() {
        return donationType;
    }

    public String getStatus() {
        return status;
    }

    public int getState() {
        return state;
    }

    public String getRiderkey() {
        return riderkey;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getStreet() {
        return street;
    }

    public String getfName() {
        return fName;
    }

    public String getKey() {
        return key;
    }

    public String getRiderdate() {
        return riderdate;
    }

    public String getRidertime() {
        return ridertime;
    }

    public String getDonationWeight() {
        return donationWeight;
    }

    public String getAddress() {
        return address;
    }

    public String getUserID() {
        return userID;
    }

    public String getMobile() {
        return mobile;
    }

    public String getRiderid() {
        return riderid;
    }

    public String getDonationVehivle() {
        return donationVehivle;
    }

    public String getDonationdate() {
        return donationdate;
    }

    public String getDonationtime() {
        return donationtime;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }
}
